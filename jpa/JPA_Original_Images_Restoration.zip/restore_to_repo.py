#!/usr/bin/env python3
"""Copy exact original JPA PNG thumbnails from this package into a git clone."""
import argparse
import csv
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def git_blob_sha(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("repo", type=Path, help="Path to local technical-articles git clone")
    p.add_argument("--force", action="store_true", help="Replace a file even if its current SHA differs from the audit")
    a = p.parse_args()
    repo = a.repo.resolve()
    if not (repo / "jpa" / "index.html").is_file() or not (repo / ".git").exists():
        p.error("Not a technical-articles git clone: " + str(repo))
    with (HERE / "audit.csv").open(newline="", encoding="utf-8") as f:
        items = list(csv.DictReader(f))
    if len(items) != 18:
        raise RuntimeError("Expected 18 image records, found " + str(len(items)))

    failures=[]
    staged=[]
    for item in items:
        rel=Path(item["repo_path"])
        src=HERE / "images" / rel
        dest=repo / rel
        if not src.exists() or not dest.exists():
            failures.append(str(rel) + ": source or target is missing")
            continue
        content=src.read_bytes()
        if hashlib.sha256(content).hexdigest()!=item["original_sha256"]:
            failures.append(str(rel) + ": uploaded original SHA-256 mismatch")
            continue
        if content[:8] != b"\x89PNG\r\n\x1a\n":
            failures.append(str(rel) + ": invalid PNG signature")
            continue
        w=int.from_bytes(content[16:20],"big")
        h=int.from_bytes(content[20:24],"big")
        if (w,h)!=(int(item["original_width"]),int(item["original_height"])):
            failures.append(str(rel) + ": incorrect PNG dimensions")
            continue
        existing=dest.read_bytes()
        if git_blob_sha(existing)!=item["previous_git_blob_sha"] and existing!=content and not a.force:
            failures.append(str(rel) + ": existing file changed since audit, use --force only after inspection")
            continue
        staged.append((src,dest,content,rel))
    if failures:
        print("No files changed. Preflight errors:",file=sys.stderr)
        for x in failures:print(" -",x,file=sys.stderr)
        sys.exit(1)

    for src,dest,content,rel in staged:
        shutil.copyfile(src,dest)
        assert dest.read_bytes()==content
        print("Restored",rel)
    print("\nRestored",len(staged),"original PNG files, with no resizing or recompression.")
    print("Next: cd to your repository, run 'git status', then 'git add jpa', 'git commit', and 'git push'.")


if __name__ == "__main__":
    main()
