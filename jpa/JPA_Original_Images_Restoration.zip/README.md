# Restore the original JPA publication thumbnails

This package contains **18 exact, unmodified PNG uploads** mapped to their existing
`jpa/YYYY-MM-DD_publication-title/thumbnail.png` locations.

The other four JPA thumbnails were checked and already have suitable resolution.
They are not replaced.

## Windows (recommended)

1. Download this ZIP and extract it into a folder on your computer.
2. Open PowerShell (or a terminal) in the extracted folder.
3. Run:

   ```powershell
   python restore_to_repo.py "C:\path\to\technical-articles"
   ```

   Replace the path with the location of your cloned GitHub repository.
   This copies the original PNGs into the correct publication directories.
4. Review `git status` in your repository. Only the 18 `thumbnail.png` files
   should have changed. The metadata and HTML are intentionally untouched.
5. Commit and push:

   ```powershell
   cd "C:\path\to\technical-articles"
   git add jpa
   git commit -m "Restore full-resolution original JPA thumbnails"
   git push
   ```

Alternatively, you can extract the ZIP directly into the root of your local
`technical-articles` repository. The paths in `images/jpa/` must then be copied
into the repository's `jpa/` folder, overwriting existing `thumbnail.png` files.
The script handles this safely and verifies all 18 byte-for-byte.

## Verification and safeguards

- Every restored file is the exact PNG that was uploaded to ChatGPT, without
  resizing, palette conversion, or lossy compression.
- Before overwriting, the script checks that your existing thumbnail still has
  the Git blob hash recorded at the time of this audit. This protects any newer
  manual edits. Use `--force` only after reviewing a mismatch.
- The script checks all the source SHA-256 hashes and PNG dimensions.
- The JPA HTML generator does not need modification. The existing `.png` paths
  are reused, and publication metadata, CSS and ordering are unchanged.
- `audit.csv` contains the before-and-after size information.

**GitHub Pages:** Once committed and pushed, the existing JPA publication
workflow should validate the metadata and HTML automatically. Your browser may
require a hard refresh (Ctrl+Shift+R) to invalidate cached thumbnails.

This package is prepared for restoring the GitHub repository. Creating this ZIP
alone does not update the remote GitHub files.
